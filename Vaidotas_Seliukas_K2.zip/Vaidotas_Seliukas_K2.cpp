#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>

using namespace std;

class Skaiciavimai
{
public:

        double Miltu_svoris, Pardavimo_kaina, Savikaina, Prekiu_kiekis, Pelnas, PVM;
        string Rusis;

    void Ivestis()
    {
        cout<<"Iveskite miltu pavadinima "<<endl;
        cin>>Rusis;

        cout<<"Iveskite miltu svori "<<endl;
        cin>>Miltu_svoris;
        if(cin.fail())
        {
        cin.clear();
        cin.ignore(256,'\n');
        cout<<"Veskite is naujo"<<endl;
        cin>>Miltu_svoris;
        }

        cout<<"Iveskite prekiu kieki "<<endl;
        cin>>Prekiu_kiekis;
        if(cin.fail())
        {
        cin.clear();
        cin.ignore(256,'\n');
        cout<<"Veskite is naujo"<<endl;
        cin>>Prekiu_kiekis;
        }
    }

    void Savakaina()
    {
    Savikaina = Miltu_svoris * 2;
    };

    void Pardavimokaina()
    {
     Pardavimo_kaina = Savikaina*1.5;
    }

    void Pelnaas ()
    {
     Pelnas = (Pardavimo_kaina - Savikaina)* Prekiu_kiekis;
    }

    void PVeMas()
    {
     PVM = Pelnas * 0.21;
    }

};

struct As
{
    string vardas={"Vaidotas_Seliukas"};
};

int main()
{

    vector<Skaiciavimai> Lenta;
    As a;
    cout<<"Darba atliko: MRf-17 "<<a.vardas<<endl;
    cout<<endl;
    Skaiciavimai x;
    int n, k, l=1, w=1;
    string pavadinimas, txt={".txt"}, pavarde, tarpas={"_"}, data={"data"}, result={"result"} ;
    pavadinimas=a.vardas+tarpas+data+txt;
    cout<<pavadinimas<<endl;


    ofstream kiek (pavadinimas);
    n=5+20173320%4;
    cout<<n<<endl;
    kiek<<n;
    kiek.close();


    ifstream in (pavadinimas);
    in>>k;
    in.close();



    for(int i=1; i<=k; i++)
    {
     x.Ivestis();

     x.Savakaina();

     x.Pardavimokaina();

     x.Pelnaas();

     x.PVeMas();

     Lenta.push_back(x);
    }

    pavadinimas=a.vardas+tarpas+result+txt;
    cout<<pavadinimas<<endl;


    cout.fill('-');
    cout.width(120);
    cout<<left<<"|";
    cout<<"|"<<endl;
    cout.fill(' ');
    cout <<"|"<<setw(10)<<left<<"Eiles_Nr "<<"|"<<setw(15)<<left<<"Pavadinimas "<<"|"<<setw(15)<<left<<"Miltu svoris "<<"|"<<setw(15)<<right<<"Prekiu kiekis "<<"|"<<setw(15)<<left<<"Savikaina "<<"|"<<setw(20)<<left<<"Pardavimu kaina "<<"|"<<setw(10)<<left<<"Pelnas "<<"|"<<setw(12)<<right<<"PVM* "<<"|"<<endl;
    cout.fill('-');
    cout.width(120);
    cout<<left<<"|";
    cout<<"|"<<endl;
    cout<<"-"<<endl;
    cout.fill(' ');
    for (Skaiciavimai q : Lenta)
    cout <<"|"<<setw(10)<<left<<l++<<"|"<<setw(15)<<left<<q.Rusis<<"|"<<setw(15)<<left<<q.Miltu_svoris<<"|"<<setw(15)<<right<<q.Prekiu_kiekis<<"|"<<setw(15)<<left<<q.Savikaina<<"|"<<setw(20)<<left<<q.Pardavimo_kaina<<"|"<<setw(10)<<left<<q.Pelnas<<"|"<<setw(12)<<right<<q.PVM<<"|"<<endl;

    cout.fill('-');
    cout.width(120);
    cout<<left<<"|";
    cout<<"|"<<endl;
    cout<<"-"<<endl;
    cout.fill(' ');


    ofstream out(pavadinimas, ios::app);
    for (Skaiciavimai q : Lenta)
    out <<w++<<" "<<q.Rusis<<" "<<q.Miltu_svoris<<" "<<q.Prekiu_kiekis<<" "<<q.Savikaina<<" "<<q.Pardavimo_kaina<<" "<<q.Pelnas<<" "<<q.PVM<<" "<<endl;
    out.close();

    return 0;
}
